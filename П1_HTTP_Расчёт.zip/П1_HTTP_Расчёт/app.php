<?php
declare(strict_types=1);

function prices(): array
{
    $variant = (require __DIR__ . '/config.php')['variant'];
    return match ($variant) {
        'A' => ['Кабель', 12500, 'Чехол', 7500],
        'B' => ['Тетрадь', 8000, 'Блокнот', 4000],
        'C' => ['Ручка', 3000, 'Карандаш', 1500],
        default => throw new InvalidArgumentException('Вариант должен быть A/B/C'),
    };
}

function quantity(mixed $raw): int
{
    if (!is_string($raw) || preg_match('/^(0|[1-9][0-9]?)$/D', $raw) !== 1) {
        throw new InvalidArgumentException('Количество: целое от 0 до 99');
    }
    return (int) $raw;
}

function getQuantities(array $query): array
{
    // TODO P01-GET: Прочитать два количества из GET и проверить готовой quantity().
    return [quantity($query['qty_first'] ?? null), quantity($query['qty_second'] ?? null)];
}

function postQuantities(array $post): array
{
    // TODO P01-POST: Прочитать количества из POST, а не из строки запроса.
    return [quantity($post['qty_first'] ?? null), quantity($post['qty_second'] ?? null)];
}

function totalMinor(int $first, int $second): int
{
    // TODO P01-SUM: Вычислить сумму в минимальных денежных единицах.
    $prices = prices();
    return $first * $prices[1] + $second * $prices[3];
}

function practiceHeader(): void
{
    header('X-Practice: 01');
}

function h(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function page(string $title, string $body): void
{
    header('Content-Type: text/html; charset=UTF-8');
    practiceHeader();
    if ($_SERVER['REQUEST_METHOD'] === 'HEAD') {
        return;
    }
    echo '<!doctype html><html lang="ru"><meta charset="utf-8"><link rel="stylesheet" href="/style.css">';
    echo '<title>' . h($title) . '</title><h1>' . h($title) . '</h1>' . $body
        . '<footer><small>Выполнил: Шебалин Никита cs-306 (c) · Практическая №1</small></footer></html>';
}
