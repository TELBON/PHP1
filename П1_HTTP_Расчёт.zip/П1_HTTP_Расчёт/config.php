<?php
return ['variant' => 'A'];
